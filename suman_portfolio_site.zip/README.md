# Suman Portfolio Starter

This folder contains a ready-to-publish single-page portfolio site for **Suman Teja Muchunoori**.

## Quick Publish (GitHub Pages)
1. Sign in to GitHub → create a new public repo named **sumanteja.github.io**.
2. Upload `index.html` and `resume.pdf` to the root of the repo.
3. Visit https://sumanteja.github.io

## Customize
- Edit `index.html` to update project links and LinkedIn URL.
- Replace `resume.pdf` with your real resume.

Generated on 2025-09-27.
